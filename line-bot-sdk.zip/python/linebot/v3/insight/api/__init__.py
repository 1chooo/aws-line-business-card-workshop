# flake8: noqa

# import apis into api package
from linebot.v3.insight.api.insight import Insight


# Async version
from linebot.v3.insight.api.async_insight import AsyncInsight

